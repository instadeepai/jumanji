This contains the old env_viewer.py class which we can choose to use to still view the environment. 

There is a new one provided by the new jumanji version. 
